from .base import SqlHelper


class Authenticate(SqlHelper):

    def __init__(self):
        self.id = id

    def authenticate(self, email):
        query = "SELECT * FROM user WHERE email = '%s'" % email
        return self.fetch_one(query)

    def create_account(self, firstname, lastname, email, pw_hash):
        query = ("INSERT INTO user(firstname, lastname, email, password) "
                 "VALUES (%s, %s, %s, %s)")
        return self.add(query, (firstname, lastname, email, pw_hash))
