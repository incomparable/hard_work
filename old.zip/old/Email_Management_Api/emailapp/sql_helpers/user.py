from .base import SqlHelper


class User(SqlHelper):

    def __init__(self):
        pass

    def get_email_user(self):
        query = "SELECT * FROM email_user"
        return self.fetch_all(query)
