from .base import SqlHelper


class Templates(SqlHelper):

    def __init__(self):
        pass

    def get_templates(self):
        query = "SELECT * FROM templates WHERE system_template='false'"
        return self.fetch_all(query)

    def get_template_by_id(self, template_id):
        query = "SELECT * FROM templates WHERE id = '%s'" % template_id
        return self.fetch_one(query)

    def get_template_vars(self):
        query = "SELECT * FROM templatevars"
        return self.fetch_all(query)

    def get_template_vars_by_template_id(self, template_id):
        query = "SELECT * FROM templatevars where templates_id=%s" % template_id
        return self.fetch_all(query)

    def get_template_by_name(self, template_name):
        query = "SELECT * FROM templates WHERE name = '%s'" % str(template_name)
        return self.fetch_one(query)

    def insert_system_emails(self, user_id, email_type, status):
        query = "INSERT INTO system_emails(user_id, email_type, status) " \
                "VALUE (%s, %s, %s)"
        return self.add(query, (user_id, email_type, status))
