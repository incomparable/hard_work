from .base import SqlHelper


class CampaignHelper(SqlHelper):

    def __init__(self):
        pass

    # def get_latest_campaign(self):
    #     query = "SELECT id, list_id, templates_id, status, created_on, name FROM campaigns " \
    #             "order by id desc"
    #
    #     campaigns = self.fetch_all(query)
    #     if campaigns:
    #         return campaigns[0]
    #
    #     return None

    def get_latest_campaign(self):
        query = "SELECT id, list_id, templates_id, status, created_on, name FROM campaigns " \
                "where is_ab_campaign= 0 order by id desc"

        campaigns = self.fetch_all(query)
        if campaigns:
            return campaigns[0]

        return None

    def get_campaign_by_id(self, id):
        query = "SELECT id, list_id, templates_id, status, created_on, name, " \
                "parent_campaign_id FROM campaigns " \
                "WHERE id=%s" % id

        return self.fetch_one(query)

    def get_campaign_by_parent_campaign_id(self, id):
        query = "SELECT id, list_id, templates_id, status, created_on, name, " \
                "parent_campaign_id FROM campaigns " \
                "WHERE parent_campaign_id=%s" % id

        return self.fetch_one(query)

    def get_email_configurations(self):
        query = "SELECT id, list_id, templates_id, status, created_on, name FROM campaigns " \
                "WHERE status='ACTIVE' or status='PROCESSING'"
        return self.fetch_all(query)

    def get_email_configurations_processing(self):
        query = "SELECT id, list_id, templates_id, status, created_on, name FROM campaigns " \
                "WHERE status='PROCESSING'"
        return self.fetch_all(query)

    def update_email_configration_status(self, id, status):
        query = "UPDATE campaigns SET status = '%s' WHERE id = '%s'" % (status, id)
        self.update_email_config(query)

    def get_all_non_ab_campaigns(self, user_id):
        query = "SELECT * FROM campaigns cp left join list ls on " \
                "ls.id=cp.list_id " \
                "where is_ab_campaign=%s and cp.user_id=%s order by cp.id desc" \
                % (False, user_id)

        return self.fetch_all(query)

    def get_all_ab_campaigns(self, user_id):
        query = "SELECT * FROM campaigns cp inner join list ls on " \
                "ls.id=cp.list_id " \
                "where is_ab_campaign=%s and cp.user_id=%s and parent_campaign_id is null" \
                " order by cp.id desc" \
                % (True, user_id)

        return self.fetch_all(query)

    def create_campaign(self, name, templates_id, status, user_id, state,
                        percentage, list_id=None, is_ab_campaign=False, parent_campaign_id=None):

        query = "INSERT INTO campaigns(name, list_id, templates_id, status, user_id, " \
                "campaign_state, parent_campaign_id, is_ab_campaign, test_percentage) " \
                "VALUE (%s, %s, %s, %s, %s, %s, %s, %s, %s)"

        campaign_id = self.add(query, (name, list_id, str(templates_id), str(status),
                                       user_id, str(state), parent_campaign_id, is_ab_campaign, percentage))
        return campaign_id

    def update_campaign(self, list_id, campaign_name, state, campaign_id):
        query = "UPDATE campaigns SET list_id = '%s', name = '%s', campaign_state = '%s' WHERE id = '%s'" % (list_id, campaign_name, state, campaign_id)
        self.update_email_config(query)

    def get_campaign(self, campaign_id, user_id):
        query = "SELECT * FROM campaigns WHERE id=%s and user_id=%s" % (campaign_id, user_id)
        return self.fetch_one(query)

    def delete_campaign(self, id, user_id):
        campaign = self.get_campaign(id, user_id)
        if campaign:
            campaign_query = "DELETE FROM campaigns WHERE id = '%s' and user_id=%s" % (id, user_id)
            email_result_query = "DELETE FROM email_results WHERE campaign_id = '%s'" % id
            self.delete_record(campaign_query)
            self.delete_record(email_result_query)

    def update_campagin_name_by_id(self, name, id):
        query = "UPDATE campaigns SET name = '%s' WHERE id = '%s'" % (name, id)
        self.update_email_config(query)

    def update_campagin_state_by_id(self, status, campaign_id):
        query = "UPDATE campaigns SET campaign_state = '%s'WHERE id = '%s'" % (status, campaign_id)
        self.update_email_config(query)

    def update_campagin_list_id(self, list_id, id):
        query = "UPDATE campaigns SET list_id = '%s' WHERE id = '%s'" % (list_id, id)
        self.update_email_config(query)

    def get_last_id(self):
        query = ''
        self.fetch_one(query)

    def get_queued_time(self, id):
        query = "SELECT queued_time FROM campaigns WHERE id=%s" % id
        return self.fetch_one(query)

    def get_test_percentage(self, campaign_id):
        query = "SELECT test_percentage FROM campaigns WHERE id=%s " % campaign_id
        return self.fetch_one(query)

    def check_is_ab_campaign(self, campaign_id):
        query = "SELECT is_ab_campaign FROM campaigns cp where id=%s" % campaign_id
        return self.fetch_all(query)

    def get_campaign_by_parent_id(self, parent_campaign_id):
        query = "SELECT parent_campaign_id FROM campaigns " \
                "WHERE id=%s" % parent_campaign_id
        return self.fetch_all(query)

