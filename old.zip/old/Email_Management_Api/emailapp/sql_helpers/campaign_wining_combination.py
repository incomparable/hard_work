from .base import SqlHelper


class CampaignWiningHelper(SqlHelper):

    def __init__(self):
        pass

    def create_Campaign_wining_combination(self, campaign_id, rate, time_after, time_type):

        query = "INSERT INTO campaigns_winning_combination(campaign_id, rate, time_after, time_type) " \
                "VALUE (%s, %s, %s, %s)"

        return self.add(query, (campaign_id, rate, time_after, time_type))

    def get_all_combinations(self, campaign_id):
        query = "SELECT rate, time_after, time_type FROM campaigns_winning_combination " \
                "WHERE campaign_id=%s" % campaign_id
        return self.fetch_one(query)

