from .base import SqlHelper


class ReadyToSendEmailsHelper(SqlHelper):

    def __init__(self):
        pass

    def add_ready_to_emails(self, email_address, campaign_id, html_template, subject, status):
        query = "INSERT INTO ready_to_send_emails(email_address, campaign_id, html_template, subject, status) " \
                "VALUE (%s, %s, %s, %s, %s)"

        self.add(query, (email_address, campaign_id, html_template, subject, status))

    def get_all_emails_to_queued(self, campaign_id):
        query = "Select * from ready_to_send_emails " \
                "where (status='READY_TO_SEND' or status='QUEUED') and campaign_id=%s;" % campaign_id

        return self.fetch_all(query)

    def get_total_email_in_segment(self, list_id):
        query = "Select * from list_segments where list_id=%s" % list_id
        return self.fetch_all(query)

    def get_error_send_emails(self, campaign_id):
        query = "Select * from ready_to_send_emails " \
                "where status='SENT' and campaign_id=%s;" % campaign_id
        return self.fetch_all(query)

    def get_error_emails(self, campaign_id):
        query = "Select * from ready_to_send_emails " \
                "where status='ERROR' and campaign_id=%s;" % campaign_id
        return self.fetch_all(query)

    def get_send_emails(self, campaign_id):
        query = "Select * from ready_to_send_emails " \
                "where status='SENT' and campaign_id=%s;" % campaign_id
        return self.fetch_all(query)

