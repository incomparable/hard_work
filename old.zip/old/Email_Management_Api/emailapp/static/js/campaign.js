$(function(){
    $(".email_graph").each(function(){
        var self = $(this);
        var campaign_id = $(this).attr("campaign_id");
        $.get("/campaign/get-graph-data/"+ campaign_id, function(response){
        var total = response.total_emails;
        var sent_emails =  response.sent_emails;
        var error_emails =  response.error_emails;
        var dataPoints = []
        dataPoints.push({
            "name": "QUEUED EMAIL(s)",
            "y": total,
            "color": "#44b9b0"
        });
        dataPoints.push({
            "name": "EMAIL(s) SENT",
            "y": sent_emails,
            "color": "#0c6197"
        });

        dataPoints.push({
            "name": "EMAIL(s) ERROR",
            "y": error_emails,
            "color": "#FF3C33"
        });

        var graph_id = self.attr("id");
        Highcharts.chart(graph_id, {
            chart: {
                type: 'column'
            },
            title: {
                text: ''
            },
            xAxis: {
                categories: ['Campaign Progress']
            },
            yAxis: {
                enabled: false,
                min: 0,
                title: {
                    text: ''
                },
                stackLabels: {
                    enabled: true,
                    style: {
                        fontWeight: 'bold',
                        color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
                    }
                }
            },

            tooltip: {
                headerFormat: '<b>{point.x}</b><br/>',
                pointFormat: '{point.stackTotal}'
            },

            series: [{
                name: 'Sent',
                color: 'green',
                data: [sent_emails]
            },
            {
                name: 'Error',
                color: 'red',
                data: [error_emails]
            },
            {
                name: 'Total',
                color: 'black',
                data: [total]
            }]
        });
      });
    });
});
