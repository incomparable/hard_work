from emailapp.helpers.sqlhelper import *
from emailapp.decorate import *
import os
from emailapp.sql_helpers import templates, authenticate, user, lists, \
    campaign_helper, campaign_stats
from emailapp import *
from flask import Flask
# from conf.config import EMAIL_OPEN_URL, EMAIL_CLICK_URL, PYTRACKING_SECRET_KEY, \
#     APP_ROOT, APP_STATIC
from conf.config import *
from emailapp.tracking.email_tracking import EmailTracking
from flask import url_for
from flask import jsonify
import json
from string import Template
from emailapp.helpers.smtp_email import SmtpEmail
import pytracking

template_helper = templates.Templates()
user_authenticate = authenticate.Authenticate()
email_user = user.User()
list_helper = lists.Lists()
campaign_stats_helper = campaign_stats.CampaignStatsHelper()
track_email = EmailTracking()
# smtp_email_obj = smtp_email.SmtpEmail()


def register():
    try:
        if request.method == 'POST':
            firstname = request.form['firstname']
            lastname = request.form['lastname']
            email = request.form['email']
            password = request.form['password']

            pw_hash = bcrypt.generate_password_hash(password).decode('utf-8')
            user_authenticate.create_account(firstname, lastname, email, pw_hash)
            return redirect('/login')
        return render_template('register.html')
    except:
        context = {"msg": "Email already used"}
        return render_template('register.html', **context)


def login():
    try:
        if request.method == 'POST':
            email = request.form['email']
            password = request.form['password']
            user = user_authenticate.authenticate(email)
            pw_hash = user[4]
            print('logging in')
            auth = bcrypt.check_password_hash(pw_hash, password)
            print('logging in success')
            if auth:
                session['user'] = user[0]
                session['email'] = email
                # return redirect("dashboard")
                return redirect("segment/create/")
            else:
                msg = {'msg': "Invalid email/password"}
                return render_template('login.html', **msg)
        return render_template('login.html')
    except:
        msg = {'msg': "Invalid email/password"}
        return render_template('login.html', **msg)


@login_required
def create_user():
    try:
        if request.method == 'POST':
            name = request.form['name']
            email = request.form['email']
            insert_email_user(name, email)
            return redirect('/dashboard')
        return render_template('create_user.html')

    except:
        msg = {"msg": "Email already used"}
        return render_template('create_user.html', **msg)


@login_required
def delete_user(list_segment_id, list_id):
    try:
        segment = list_helper.get_list_by_id(list_id, request.user)
        id = segment[0]
        name = segment[1]
        delete_listsegment_user_by_id(list_segment_id)
        context = {"data": list_helper.get_list_segment_by_listid(list_id),
                        "segment_name": name,  "segment_id": id}
        return render_template('segments/segment.html', **context)
    except Exception as e:
        print('[Accounts] :: delete_user() :: Got exception: %s' % e)


@login_required
def signout():
    session.clear()
    return redirect('/login')


def email_opened(params):
    try:
        url = '%s/%s' % (EMAIL_OPEN_URL, params)
        print(PYTRACKING_SECRET_KEY)
        full_url = url
        tracking_result = pytracking.get_open_tracking_result(
            full_url, base_open_tracking_url=EMAIL_OPEN_URL)

        campaign_id = tracking_result.metadata['campaign_id']
        template_id = tracking_result.metadata['template_id']
        segment_id = tracking_result.metadata['segment_id']

        campaign_stats_helper.add_campaign_open_stats(campaign_id,
                                                      segment_id,
                                                      template_id,
                                                      tracking_result.is_open_tracking,
                                                      0,
                                                      '')

        return "Test"
    except Exception as e:
        return e


def click_tracking(params):
    try:
        url = '%s/%s' % (EMAIL_CLICK_URL, params)
        full_url = url
        tracking_result = pytracking.get_click_tracking_result(
            full_url, base_click_tracking_url=EMAIL_CLICK_URL)

        campaign_id = tracking_result.metadata['campaign_id']
        template_id = tracking_result.metadata['template_id']
        segment_id = tracking_result.metadata['segment_id']

        campaign_stats_helper.add_campaign_click_stats(campaign_id,
                                                       segment_id,
                                                       template_id,
                                                       0, tracking_result.is_click_tracking,
                                                       tracking_result.tracked_url)
        print (tracking_result)

        return redirect(tracking_result.tracked_url)

    except Exception as e:
        print(e)


def send_system_email():
    try:
        user_id = request.json.get('user_id')
        email_type = request.json.get('email_type')
        template = template_helper.get_template_by_name(email_type)
        status = "ACTIVE"
        templateId = template[0]
        if not template:
            return jsonify("Email template not found")
        email_address = 'anaconda.wb@gmail.com'
        subject = 'smtp_email'
        html = build_template(templateId)
        smtp_email_obj = SmtpEmail(email_address, subject, html)
        smtp_email_obj.send()
        template_helper.insert_system_emails(user_id, email_type, status)
        return jsonify("EMAIL SENT")
    except Exception as e:
        print(e)


def build_template(templateId):

    app_static_path = APP_STATIC

    file_path = '%s/%s' % (app_static_path, 'email_template')

    template_obj = template_helper.get_template_by_id(templateId)
    template_name = template_obj[2]
    template_path = file_path + template_name
    with open(r'%s' % template_path, 'r') as f:
        template_content = f.read()

    html_template = Template(template_content)

    data = template_helper.get_template_vars_by_template_id(templateId)

    key_val = {}
    for d in data:
        template_key = d[1]
        template_value = d[2]
        if template_key not in key_val:
            key_val[template_key] = ""

        key_val[template_key] = template_value

    html = html_template.substitute(key_val)
    return html
