from emailapp import *
from emailapp.views.campaigns import create_campaign, campaigns, \
    delete_campaign, get_campaigns, edit_campaign,\
    get_campaign_graph_data, post_toggle_data,\
    create_ab_campaigns, get_ab_campaign_dashboard, \
    ab_campaigns, delete_campaign_ab

from emailapp.views.segments import create_segment, show_segment, update_segment, \
    get_list_segments, delete_segment, segment_name_update, list_segment, template

from emailapp.views.accounts import register, login, delete_user,\
    create_user, signout, email_opened, click_tracking, send_system_email


#############################################
#                                           #
#               Accounts                    #
#                                           #
#############################################
"""" User Registration. """


@app.route('/register/', methods=['GET', 'POST'])
def route_user_register():
    return register()


""" User Login. """


@app.route('/login/', methods=['GET', 'POST'])
def route_user_login():
    return login()


""" User Signout. """


@app.route('/signout/', methods=['GET', 'POST'])
def route_user_signout():
    return signout()


#############################################
#                                           #
#               Campaigns                   #
#                                           #
#############################################
""" Create campaign """


@app.route('/campaigns/create/', methods=['GET', 'POST'])
def route_create_campaign():
    return create_campaign()


""" Shows the Dashboard by Current Campaign Id. """


@app.route('/', methods=['GET', 'POST'])
@app.route('/dashboard/')
def route_dashboard():
    return get_campaigns()


""" Show the Dashboard by Campaign_id. """


@app.route('/dashboard/<int:campaign_id>/')
def route_dashboard_campaigns(campaign_id):
    return get_campaigns(campaign_id)


""" Show the List of Campaigns. """


@app.route('/campaigns/', methods=['GET', 'POST'])
def route_campaign():
    return campaigns()


""" Delete Campaign by  Campaign_id """


@app.route('/campaign/delete/<int:id>/', methods=['GET', 'POST'])
def campaign_delete(id):
    return delete_campaign(id)


""" Post the value of toggle button """


@app.route('/mark_campaign_as_published/', methods=['GET', 'POST'])
def route_mark_campaign_as_published():
    return post_toggle_data()


""" Edit Campaign """


@app.route('/edit/campaign/<int:id>/', methods=['GET', 'POST'])
def route_campaign_edit(id):
    return edit_campaign(id)


""" Get Graph Data by ajax """


@app.route('/campaign/get-graph-data/<int:id>/', methods=['GET', 'POST'])
def route_campaign_graph_data(id):
    return get_campaign_graph_data(id)


""" Create Ab-Campaign """


@app.route('/campaigns/ab/create/', methods=['GET', 'POST'])
def route_get_create_ab_campaigns():
    return create_ab_campaigns()


""" Get Ab-Campaign """


@app.route('/campaigns/ab/', methods=['GET', 'POST'])
def route_get_ab_campaign():
    return ab_campaigns()


""" Get Dashboard by campaign_id by Campaign_id """


@app.route('/campaigns/ab/dashboard/', methods=['GET', 'POST'])
def route_ab_campaigns_dashboard():
    return get_ab_campaign_dashboard()


""" Get Dashboard by campaign_id """


@app.route('/campaigns/ab/dashboard/<int:campaign_id>/')
def route_ab_campaigns_dashboard_id(campaign_id):
    return get_ab_campaign_dashboard(campaign_id)


""" Delete Ab-Campaign by campaign_id """


@app.route('/campaign/delete/ab/<int:id>/', methods=['GET', 'POST'])
def route_campaign_delete(id):
    return delete_campaign_ab(id)


@app.route('/v1/email/queue/add/', methods=['POST'])
def route_send_system_email():
    return send_system_email()


""" Open Email handler """


@app.route('/e/o/<string:params>/', methods=['GET'])
def route_open_email(params):
    return email_opened(params)


""" Click link handler """


@app.route('/e/c/<string:params>/', methods=['GET'])
def route_click_tracking(params):
    return click_tracking(params)


""" Show Tempalte """


@app.route('/template/', methods=['GET', 'POST'])
def route_get_template():
    return template()


#############################################
#                                           #
#                 Segments                  #
#                                           #
#############################################
# not in use
# """
# Create User
# """
# @app.route('/create_email_user/', methods=['GET', 'POST'])
# def route_create_email_user():
#     return create_user()


""" Delete User """


@app.route('/delete_user/<int:list_segment_id>/<int:list_id>/',
           methods=['GET', 'POST'])
def route_user_delete(list_segment_id, list_id):
    return delete_user(list_segment_id, list_id)


""" Create New Segment. """


@app.route('/segment/create/', methods=['GET', 'POST'])
def route_create_segment():
    return create_segment()


""" Get the list of Segments. """


@app.route('/segments/', methods=['GET', 'POST'])
def route_list_segments():
    return get_list_segments()


""" Get Sengments by segment_id. """


@app.route('/segment/<int:id>/', methods=['GET', 'POST'])
def route_show_segment(id):
    return show_segment(id)


""" Show the list of sengment by segment_id. """


@app.route('/list_segment/<int:id>/', methods=['GET', 'POST'])
def route_list_segment(id):
    return list_segment(id)


""" Delete Segment by segment_id. """


@app.route('/delete/segment/<int:id>/', methods=['GET', 'POST'])
def route_delete_segment(id):
    return delete_segment(id)


""" Update Segment Name """


@app.route('/update/segment/name/', methods=['POST'])
def route_update_segment_name():
    return segment_name_update()


""" Segment Update """


@app.route('/segment/update/<int:id>/', methods=['GET', 'POST'])
def route_update_segment(id):
    return update_segment(id)
