import os

MYSQL_USER = 'root'

MYSQL_PASS = '123'

MYSQL_HOST = '127.0.0.1'

CONNECT_TIMEOUT = 1000


# DBNAME = 'emailparser_db'
DBNAME = 'email_management_db'

APP_ROOT = os.path.dirname(os.path.abspath(__file__))  # refers to application_top

APP_STATIC = os.path.join(APP_ROOT, 'static')

BASE_URL = 'http://0.0.0.0:8000'

EMAIL_OPEN_URL = BASE_URL + '/e/o/'  # Open Email handler

EMAIL_CLICK_URL = BASE_URL + '/e/c/'  # Click link handler

PYTRACKING_SECRET_KEY = b'Ym8UYSnPLenVI_7DW-mJF0IG9B9k9tiVaiUh9Aj9RRY='


APP_HOST = '0.0.0.0'

APP_PORT = 8000

APP_DEBUG = True

EMAIL_LIMIT = 1000

EMAIL_TIME_LIMIT_IN_MINUTES = 60

APP_ROOT = os.path.dirname(os.path.abspath(__file__))  # refers to application_top

APP_STATIC = os.path.join(APP_ROOT, 'static')

USE_AWS_EMAIL_SERVER = False

LOGIN_EMAIL = 'kgaurav.ameotech@gmail.com'

LOGIN_PASSWORD = 'GK@ameo121'

BASE_URL = 'http://0.0.0.0:8000'
