import mysql.connector
from celery import Celery
from conf.config import MYSQL_USER, MYSQL_PASS, MYSQL_HOST, DBNAME, CONNECT_TIMEOUT,\
    CELERY_BROKER_URL, CELERY_RESULT_BACKEND, USE_AWS_EMAIL_SERVER, \
    EMAIL_OPEN_URL, EMAIL_CLICK_URL, APP_ROOT, APP_STATIC
from smtp_email import SmtpEmail
from ses_email import Email
import traceback
import mysql.connector
import os
from string import Template
from sql_helpers import campaign_helper, lists, templates, email_result, ready_to_send_email_helper
import urllib
from tracking.email_tracking import EmailTracking
import pytracking
from pytracking.html import adapt_html
from datetime import datetime
from datetime import timedelta


CELERYBEAT_SCHEDULE = {
    "runs-every-60-seconds": {
        "task": "process_emails",
        "schedule": 10.0,
        "args": (),
    },
    "runs-every-70-seconds": {
        "task": "process_ab_campaign_emails",
        "schedule": 10.0,
        "args": (),
    },
    "run_send_email_120_seconds": {
        "task": "send_emails",
        "schedule": 20.0,
        "args": (),
    },
    "runs-every-300-seconds": {
        "task": "mark_campaigns_processed",
        "schedule": 30.0,
        "args": (),
     },
 }

my_sql_cursor = mysql.connector.connect(user=MYSQL_USER, password=MYSQL_PASS, host=MYSQL_HOST,
                                        database=DBNAME, connect_timeout=CONNECT_TIMEOUT)

my_sql_cursor.autocommit = False

app = Celery('tasks')

app.conf.update(
    result_expires=60,
    task_acks_late=True,
    broker_url=CELERY_BROKER_URL,
    result_backend=CELERY_RESULT_BACKEND
)

CELERY_ROUTES = {
    'tasks.send_email': {'queue': 'send_email'},
}


###############################################################################
#                                                                             #
# app.config_from_object(CELERY_CONFIG)                                       #
#   run below statement                                                       #
#   celery - A tasks.app worker - B --loglevel = info                         #
#   celery -A task.app purge                                                  #
#   celery -A tasks.app worker -B --loglevel=info -Q default,send_email -c 10 #
#                                                                             #
###############################################################################

app.conf.beat_schedule.update(CELERYBEAT_SCHEDULE)

app.conf.task_default_queue = 'default'

app.conf.task_routes = CELERY_ROUTES


@app.task(name="mark_campaigns_processed")
def mark_campaigns_processed():
    my_sql_cursor = mysql.connector.connect(user=MYSQL_USER, password=MYSQL_PASS, host=MYSQL_HOST,
                                            database=DBNAME, connect_timeout=CONNECT_TIMEOUT)

    campaign_obj = campaign_helper.CampaignHelper(my_sql_cursor=my_sql_cursor)
    list_obj = lists.Lists(my_sql_cursor=my_sql_cursor)
    email_result_obj = email_result.EmailResultHelper(my_sql_cursor=my_sql_cursor)

    try:
        campaigns = campaign_obj.get_email_configurations_processing(is_ab_campaign=False)
        my_sql_cursor.commit()
        for campaign in campaigns:
            campaign_id = campaign[0]
            is_ab_campaign = campaign[6]

            print("Processing Campaign %s" % (campaign[0]))

            list_id = campaign[1]
            all_emails = list_obj.get_list_segment_by_listid(list_id)
            break_loop = False

            for email in all_emails:
                found = email_result_obj.get_email_result_by_campaign_segment_id(email[0], campaign_id)
                if not found and len(found) <= 0:
                    break_loop = True
                    break

            if not break_loop:
                campaign_obj.update_email_configration_status(campaign_id, 'PROCESSED')

            my_sql_cursor.commit()

    except Exception as e:
        my_sql_cursor.rollback()
        print('[celery app] :: mark_campaigns_processed() :: Got exception: %s' % e)
        print(traceback.format_exc())

    try:
        print("Processing AB campaigns...")
        campaigns = campaign_obj.get_email_configurations_processing(is_ab_campaign=True)

        for campaign in campaigns:
            campaign_id = campaign[0]
            b_campaign = campaign_obj.get_campaign_by_parent_id(campaign_id)
            print('b_campaign', b_campaign)
            b_campaign_id = b_campaign[0][0]
            print('b_campaign_id', b_campaign_id)
            ready_to_send_a_emails = email_result_obj. \
                check_if_all_emails_processed_for_ab_campaign(campaign_id)

            ready_to_send_b_emails = email_result_obj. \
                check_if_all_emails_processed_for_ab_campaign(b_campaign_id)

            if len(ready_to_send_a_emails) <= 0 and len(ready_to_send_b_emails) <= 0:
                campaign_obj.update_email_configration_status(campaign_id, 'PROCESSED')
                campaign_obj.update_email_configration_status(b_campaign_id, 'PROCESSED')
            my_sql_cursor.commit()

    except Exception as e:
        my_sql_cursor.rollback()
        print('[celery app] :: mark_campaigns_processed() :: Got exception: %s' % e)
        print(traceback.format_exc())


@app.task(name="process_emails")
def process_emails_campaigns():
    try:
        my_sql_cursor = mysql.connector.connect(user=MYSQL_USER, password=MYSQL_PASS, host=MYSQL_HOST,
                                                database=DBNAME, connect_timeout=CONNECT_TIMEOUT)
        campaign_helper_obj = campaign_helper.CampaignHelper(my_sql_cursor=my_sql_cursor)
        list_obj = lists.Lists(my_sql_cursor=my_sql_cursor)
        campaigns = campaign_helper_obj.get_email_configurations()
        ready_to_send_emails_obj = ready_to_send_email_helper\
            .ReadyToSendEmailsHelper(my_sql_cursor=my_sql_cursor)

        for email_config in campaigns:
            try:
                campaign_id = email_config[0]

                if campaign_helper_obj.check_if_campaign_already_processing(campaign_id):
                    print('Already Processed # %s' % (str(campaign_id)))
                    continue

                list_id = email_config[1]
                users = list_obj.get_list_segment_by_listid(list_id)  # get segments on base of list id



                check_emails = ready_to_send_emails_obj.\
                    get_all_ready_to_send_emails_by_status_readytosend()
                total_emails = len(check_emails)

                current_time = datetime.now()
                previous_time = current_time - timedelta(hours=1)

                print('====== status ReadyToSend ======[%s]' % total_emails)

                if total_emails <= 100:
                    print('go inside the if block')

                    # Change status to PROCESSING
                    processing_status = 'PROCESSING'
                    campaign_helper_obj.update_email_configration_status(email_config[0], processing_status)

                    template_html = build_template(email_config[2])
                    subject = email_config[4]
                    if template_html:
                        try:

                            for user in users:
                                ready_email_status = "READY_TO_SEND"
                                email_address = user[1]
                                list_segment_id = user[0]
                                email_schedule_for_sending = ready_to_send_emails_obj.\
                                    check_is_emails_records(email_address, campaign_id)

                                if not email_schedule_for_sending:
                                    ready_to_send_emails_obj.\
                                        add_ready_to_emails(email_address,
                                                            campaign_id,
                                                            template_html,
                                                            subject,
                                                            ready_email_status,
                                                            list_segment_id)

                        except Exception as e:
                            print('[Tasks] :: process_email() :: %s' % e)
                            print(traceback.format_exc())

                    processing_status = 'QUEUED'
                    campaign_helper_obj.update_email_configration_status(email_config[0], processing_status)

                    my_sql_cursor.commit()
                else:
                    print('go to else part')
                    break
            except Exception as e:
                my_sql_cursor.rollback()
                print('[Tasks] :: process_email() :: %s' % e)
                print(traceback.format_exc())
    except Exception as e:
        print(e)
        print(traceback.format_exc())


@app.task(name="process_ab_campaign_emails")
def process_emails_ab_campaigns():
    try:
        my_sql_cursor = mysql.connector.connect(user=MYSQL_USER, password=MYSQL_PASS, host=MYSQL_HOST,
                                                database=DBNAME, connect_timeout=CONNECT_TIMEOUT)

        campaign_helper_obj = campaign_helper.CampaignHelper(my_sql_cursor=my_sql_cursor)

        QUEUED_TIME = datetime.now()

        list_obj = lists.Lists(my_sql_cursor=my_sql_cursor)

        campaigns = campaign_helper_obj.get_ab_campaigns()

        ready_to_send_emails_obj = ready_to_send_email_helper\
            .ReadyToSendEmailsHelper(my_sql_cursor=my_sql_cursor)

        for email_config in campaigns:
            try:
                campaign_id = email_config[0]

                if campaign_helper_obj.check_if_campaign_already_processing(campaign_id):
                    print('Already Processed # %s' % (str(campaign_id)))
                    continue

                list_id = email_config[1]

                segments = list_obj.get_list_segment_by_listid(list_id)  # get segments on base of list id

                """
                Change status to PROCESSING
                """
                processing_status = 'PROCESSING'
                campaign_helper_obj.update_email_configration_status(email_config[0], processing_status)

                template_html = build_template(email_config[2])
                subject = email_config[4]

                if template_html:
                    try:
                        segment_list = []
                        for segment_user in segments:
                            segment_list.append(segment_user)

                        test_percentage_obj = campaign_helper_obj.get_test_percentage(campaign_id)
                        test_percentage = test_percentage_obj[0]
                        segment_list_len = len(segment_list)
                        if test_percentage:
                            test_percent = int(int(segment_list_len) * int(test_percentage))/100
                            print("test_percent", test_percent)
                            campaign_first_half = int(test_percent)/2
                            print("campaign_first_half", campaign_first_half)
                            segment_first_campaign = segment_list[:int(campaign_first_half)]

                            segment_second_campaign = segment_list[
                                                      int(campaign_first_half):(int(campaign_first_half) * 2)]

                            ready_email_status = "READY_TO_SEND"

                            for segment_usr in segment_first_campaign:
                                    email_address = segment_usr[1]
                                    segment_id = segment_usr[0]
                                    ready_to_send_emails_obj.add_ready_to_emails(email_address,
                                                                                 campaign_id,
                                                                                 template_html,
                                                                                 subject,
                                                                                 ready_email_status,
                                                                                 segment_id)

                            campaign_b = campaign_helper_obj.get_campaign_by_parent_id(campaign_id)
                            campaign_b_id = campaign_b[0][0]
                            campaign_b_subject = campaign_b[0][5]

                            processing_status = 'PROCESSING'
                            campaign_helper_obj.update_email_configration_status(campaign_b_id,
                                                                                 processing_status)

                            for segment_usr in segment_second_campaign:
                                    email_address = segment_usr[1]
                                    segment_id = segment_usr[0]
                                    ready_to_send_emails_obj.add_ready_to_emails(email_address,
                                                                                 campaign_b_id,
                                                                                 template_html,
                                                                                 campaign_b_subject,
                                                                                 ready_email_status,
                                                                                 segment_id)

                            processing_status = 'QUEUED'

                            campaign_helper_obj.update_email_configration_queued_time(campaign_b_id,
                                                                                      processing_status,
                                                                                      QUEUED_TIME)

                    except Exception as e:
                        print('[Tasks] :: process_email() :: %s' % e)
                        print(traceback.format_exc())

                processing_status = 'QUEUED'
                campaign_helper_obj.update_email_configration_queued_time(email_config[0],
                                                                          processing_status,
                                                                          QUEUED_TIME)
                my_sql_cursor.commit()
            except Exception as e:
                my_sql_cursor.rollback()
                print('[Tasks] :: process_email() :: %s' % e)
                print(traceback.format_exc())
    except Exception as e:
        print(e)
        print(traceback.format_exc())


@app.task(name="send_emails")
def send_emails():
    try:
        my_sql_cursor = mysql.connector.connect(user=MYSQL_USER, password=MYSQL_PASS, host=MYSQL_HOST,
                                                database=DBNAME, connect_timeout=CONNECT_TIMEOUT)
        ready_to_send_emails_obj = ready_to_send_email_helper.\
            ReadyToSendEmailsHelper(my_sql_cursor=my_sql_cursor)

        ready_to_send_emails_records = ready_to_send_emails_obj.get_all_ready_to_send_emails()

        for emails_records in ready_to_send_emails_records:
            try:

                email_address = emails_records[1]
                campaign_id = emails_records[2]

                if not ready_to_send_emails_obj.check_if_email_already_queued(email_address,
                                                                              campaign_id):
                    ready_to_send_emails_obj.update_ready_to_send_status(campaign_id,
                                                                         email_address, "QUEUED")

                    template_html = emails_records[3]
                    subject = emails_records[4]
                    segment_id = emails_records[5]
                    list_id = emails_records[6]
                    template_id = emails_records[7]

                    # call send email
                    send_email.delay(template_html, email_address, list_id, segment_id,
                                     template_id, campaign_id, subject)

                    my_sql_cursor.commit()
            except Exception as e:
                my_sql_cursor.rollback()
                print(e)
    except Exception as e:
        print(e)


def build_template(templateId):
    template_helper = templates.Templates(my_sql_cursor=my_sql_cursor)

    app_static_path = APP_STATIC

    file_path = '%s/%s' % (app_static_path, 'email_template')

    template_obj = template_helper.get_template_by_id(templateId)
    template_name = template_obj[2]
    template_path = file_path + template_name

    with open(r'%s' % template_path, 'r') as f:
        template_content = f.read()

    html_template = Template(template_content)

    data = template_helper.get_template_vars_by_template_id(templateId)

    key_val = {}
    for d in data:
        template_key = d[1]
        template_value = d[2]
        if template_key not in key_val:
            key_val[template_key] = ""

        key_val[template_key] = template_value

    html = html_template.substitute(key_val)
    return html


@app.task(name="send_email")
def send_email(html, email_address, list_id, segment_id, template_id, campaign_id, subject):

    my_sql_cursor = mysql.connector.connect(user=MYSQL_USER, password=MYSQL_PASS, host=MYSQL_HOST,
                                            database=DBNAME, connect_timeout=CONNECT_TIMEOUT)

    email_result_obj = email_result.EmailResultHelper(my_sql_cursor=my_sql_cursor)
    ready_to_send_emails_obj = ready_to_send_email_helper.ReadyToSendEmailsHelper(my_sql_cursor=my_sql_cursor)

    list_segment_id = segment_id
    try:
        email_address = email_address

        print('[celery email Address]', email_address)

        # email_tracking_obj = EmailTracking()
        # open_url = email_tracking_obj.email_encoding(template_id, campaign_id, segment_id)

        configuration = pytracking.Configuration(
            base_open_tracking_url=EMAIL_OPEN_URL,
            base_click_tracking_url=EMAIL_CLICK_URL,
            include_webhook_url=False)

        html = adapt_html(html,
                          extra_metadata={"template_id": template_id,
                                          "segment_id": segment_id,
                                          "campaign_id": campaign_id},
                          click_tracking=True,
                          open_tracking=True,
                          configuration=configuration)

        # html = html.replace("EMAIL_OPEN_TRACK_URL", open_url)

        if USE_AWS_EMAIL_SERVER:
            mail_obj = Email(email_address, subject, html)
            # mail_obj.send()
        else:
            # set up the SMTP server
            smtp_email_obj = SmtpEmail(email_address, subject, html)
            smtp_email_obj.send()

        print("mail is sent successfully")

        email_result_obj.create_email_result(campaign_id, list_id,
                                             list_segment_id, template_id, "SENT", "SUCCESS")

        ready_to_send_emails_obj.update_ready_to_send_status(campaign_id, email_address, "SENT")
        my_sql_cursor.commit()
        print("Mail is sent successfully")
    except Exception as e:
        my_sql_cursor.rollback()

        try:
            email_result_obj.create_email_result(campaign_id, list_id, list_segment_id,
                                                 template_id, "ERROR", "ERROR")

            ready_to_send_emails_obj.update_ready_to_send_status(campaign_id,
                                                                 email_address, "ERROR")

            my_sql_cursor.commit()

        except:
            pass

        print('[Tasks] :: send_email() :: Got exception: %s' % e)
        print(traceback.format_exc())
