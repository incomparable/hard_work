from tasks import process_emails_campaigns, send_emails, send_email, mark_campaigns_processed, Flask_app


if __name__ == "__main__":

    Flask_app.run()
    process_emails_campaigns.delay()
    send_emails.delay()
    mark_campaigns_processed.delay()



