from .base import SqlHelper


class CampaignHelper(SqlHelper):

    def __init__(self, *args, **kwargs):
        super(CampaignHelper, self).__init__(*args, **kwargs)

    def create_campaign(self, name, list_id, templates_id, status, user_id):
        query = "INSERT INTO campaigns(name, list_id, templates_id, status, user_id) " \
                "VALUE (%s, %s, %s, %s, %s)"

        self.add(query, (name, str(list_id), str(templates_id), str(status), user_id))

    def get_email_configurations(self, is_ab_campaign=False):

        query = "SELECT id, list_id, templates_id, status, name, created_on, name FROM campaigns " \
                "WHERE status='ACTIVE' and campaign_state='PUBLISHED' and is_ab_campaign=%s" % is_ab_campaign

        return self.fetch_all(query)

    def get_ab_campaigns(self):

        query = "SELECT id, list_id, templates_id, status, name, created_on, name FROM campaigns " \
                "WHERE status='ACTIVE' and campaign_state='PUBLISHED' " \
                "and is_ab_campaign=%s and parent_campaign_id is null" % True

        return self.fetch_all(query)

    def get_email_configurations_processing(self, is_ab_campaign=False):
        query = "SELECT id, list_id, templates_id, status, created_on, name, " \
                "is_ab_campaign FROM campaigns " \
                "WHERE status='QUEUED' and is_ab_campaign=%s" % is_ab_campaign
        return self.fetch_all(query)

    def update_email_configration_status(self, id, status):
        query = "UPDATE campaigns SET status = '%s' WHERE id = '%s'" % (status, id)
        self.update_email_config(query)

    def update_email_configration_queued_time(self, id, status, queued_time):
        query = "UPDATE campaigns SET status = '%s', queued_time = '%s' WHERE id = %s" \
                % (status, queued_time, id)
        self.update_email_config(query)

    def get_all_email_configurations(self, user_id):
        query = "SELECT * FROM campaigns cp inner join list ls on ls.id=cp.list_id and cp.user_id=%s" % user_id
        return self.fetch_all(query)

    def get_campaign(self, campaign_id, user_id):
        query = "SELECT * FROM campaigns WHERE id=%s and user_id=%s" % (campaign_id, user_id)
        return self.fetch_one(query)

    def check_if_campaign_already_processing(self, campaign_id):
        query = "SELECT * FROM campaigns WHERE id=%s and (status='PROCESSING' or status='QUEUED')" % campaign_id
        response = self.fetch_one(query)
        if response:
            return True

        return False

    def delete_campaign(self, id, user_id):
        campaign = self.get_campaign(id, user_id)
        if campaign:
            campaign_query = "DELETE FROM campaigns WHERE id = '%s' and user_id=%s" % (id, user_id)
            email_result_query = "DELETE FROM email_results WHERE campaign_id = '%s'" % id
            self.delete_record(campaign_query)
            self.delete_record(email_result_query)

    def get_test_percentage(self, campaign_id):
        query = "SELECT test_percentage FROM campaigns WHERE id=%s " % campaign_id
        return self.fetch_one(query)

    def get_campaign_by_parent_id(self, campaign_id):
        query = "SELECT * FROM campaigns WHERE parent_campaign_id=%s" % campaign_id
        return self.fetch_all(query)
