from .base import SqlHelper


class Templates(SqlHelper):

    def __init__(self, *args, **kwargs):
        super(Templates, self).__init__(*args, **kwargs)

    def get_templates(self):
        query = "SELECT * FROM templates"
        return self.fetch_all(query)

    def get_template_by_id(self, template_id):
        query = "SELECT * FROM templates WHERE id = '%s'" % template_id
        return self.fetch_one(query)

    def get_template_vars(self):
        query = "SELECT * FROM templatevars"
        return self.fetch_all(query)

    def get_template_vars_by_template_id(self, template_id):
        query = "SELECT * FROM templatevars where templates_id=%s" % template_id
        return self.fetch_all(query)
