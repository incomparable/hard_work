from .base import SqlHelper


class Lists(SqlHelper):

    def __init__(self, *args, **kwargs):
        super(Lists, self).__init__(*args, **kwargs)

    def create_list(self, list_name, user_id):
        query = "INSERT INTO list(list_name, user_id) VALUE (%s, %s)"
        self.add(query, (list_name, user_id))

    def get_list(self, user_id):
        query = "SELECT * FROM list where user_id=%s" % user_id
        return self.fetch_all(query)

    def get_list_segment(self):
        query = "SELECT * FROM list_segments"
        return self.fetch_all(query)

    def get_listsegment_count(self, id):
        query = "SELECT COUNT(*) FROM list_segments WHERE list_id = '%s'" % id
        query_data = self.fetch_one(query)
        return query_data[0]

    def delete_list(self, id):
        list = self.get_list_by_id(id)
        if list:
            query = "DELETE FROM list WHERE id = '%s'" % id
            segment_query = "DELETE FROM list_segments WHERE list_id = '%s'" % id
            self.delete_record(query)
            self.delete_record(segment_query)

    def delete_listsegment(self, id):
        query = "DELETE FROM list_segments WHERE id = '%s'" % id
        self.delete_record(query)

    def get_list_segment_by_listid(self, list_id):
        query = "SELECT * FROM list_segments WHERE list_id = %s" % list_id
        return self.fetch_all(query)

    def get_list_by_id(self, id, user_id):
        query = "SELECT * FROM list WHERE id = '%s' and user_id=%s" % (id, user_id)
        return self.fetch_one(query)

    def get_list_by_listname_user_id(self, list_name, user_id):
        query = "SELECT * FROM list WHERE list_name = '%s' and user_id=%s" % (list_name, user_id)
        return self.fetch_one(query)

    def update_segment_name_by_id(self, name, list_id):
        query = "Update list set list_name=%s where id=%s"
        self.add(query, (str(name), list_id))
