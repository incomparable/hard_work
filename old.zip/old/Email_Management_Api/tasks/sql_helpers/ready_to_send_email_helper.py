from .base import SqlHelper


class ReadyToSendEmailsHelper(SqlHelper):

    def __init__(self, *args, **kwargs):
        super(ReadyToSendEmailsHelper, self).__init__(*args, **kwargs)

    def add_ready_to_emails(self, email_address, campaign_id, template_html, subject, status, list_segment_id):
        query = "INSERT INTO ready_to_send_emails(email_address, campaign_id," \
                " template_html, subject, status, list_segment_id) " \
                "VALUE (%s, %s, %s, %s, %s, %s)"

        self.add(query, (email_address, campaign_id, template_html, subject, status, list_segment_id))

    def update_ready_to_send_status(self, campaign_id, email_address, status):
        query = "Update ready_to_send_emails set status=%s where campaign_id=%s and email_address=%s"
        self.add(query, (str(status), campaign_id, str(email_address)))

    def get_ready_to_send_emails__by_asc_order(self):
        query = "SELECT * FROM ready_to_send_emails ORDER BY id ASC LIMIT 10"
        return self.fetch_all(query)

    def check_is_emails_records(self, email_address, campaign_id):
        query = "Select * from ready_to_send_emails where status='READY_TO_SEND' and " \
                "email_address='%s' and campaign_id='%s'" \
                % (str(email_address), campaign_id)

        emails_records = self.fetch_all(query)
        if emails_records and len(emails_records) > 0:
            return True

        return False

    def check_if_email_already_queued(self, email_address, campaign_id):
        query = "Select * from ready_to_send_emails where status='QUEUED' and " \
                "email_address='%s' and campaign_id='%s'" \
                % (str(email_address), campaign_id)

        emails_records = self.fetch_all(query)
        if emails_records and len(emails_records) > 0:
            return True

        return False

    def get_all_ready_to_send_emails(self):
        query = "SELECT rs.id, rs.email_address, rs.campaign_id, rs.template_html, rs.subject," \
                " rs.list_segment_id, cp.list_id, cp.templates_id" \
                " FROM ready_to_send_emails rs inner join campaigns cp on cp.id = rs.campaign_id" \
                " where rs.status='READY_TO_SEND'"
        return self.fetch_all(query)

    def get_all_ready_to_send_emails_by_status_readytosend(self):
        query = "Select * from ready_to_send_emails where status='READY_TO_SEND'"
        return self.fetch_all(query)

    def get_all_ready_to_send_emails_by_status_queue(self):
        query = "Select * from ready_to_send_emails where status='QUEUED'"
        return self.fetch_all(query)

