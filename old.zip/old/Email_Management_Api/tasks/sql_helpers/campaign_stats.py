from .base import SqlHelper


class CampaignStatsHelper(SqlHelper):

    def __init__(self):
        pass

    def add_campaign_open_stats(self, email_result_id):
        query = "INSERT INTO campaign_stats(email_result_id, opened) " \
                "VALUE (%s, %s)"

        self.add(query, (email_result_id, True))
