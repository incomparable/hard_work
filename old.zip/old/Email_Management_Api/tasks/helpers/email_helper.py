from flask_mail import Mail, Message
import time
import os
from string import Template


if __name__ == '__main__':
    email = EmailHelper()
    email.process_emails()
